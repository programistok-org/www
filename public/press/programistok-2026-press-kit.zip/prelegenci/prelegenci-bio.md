# Programistok 2026 — prelegenci

Zdjęcia w katalogu `zdjecia/`. Wykorzystanie w materiałach o konferencji — bez ograniczeń.

## Wojciech Kasa
**Ścieżka IT, dzień 2:** Residuality Theory na produkcji. Jak przewidzieć awarię, zanim wydarzy się naprawdę.
Wojtek od ponad 20 lat pracuje w branży IT. Uważa, że większość błędów architektonicznych nie wynika ze złych decyzji technicznych, ale z pytań, których nikt nie zadał wystarczająco wcześnie. Dlatego, zanim zaproponuje jakiekolwiek rozwiązanie, stara się zrozumieć, co tak naprawdę boli i czy w ogóle warto to budować.

Na co dzień Lead Architect w MAK IT i współzałożyciel Arpeggia Studio, butikowej firmy konsultingowej działającej pod hasłem „compose before you code”. Arpeggia pomaga organizacjom myśleć architektonicznie, optymalizować procesy wytwarzania oprogramowania oraz prowadzi szkolenia dla architektów i zespołów deweloperskich.

Zwycięzca O'Reilly Architectural Kata (edycja Winter 2024).
Zdjęcie: `zdjecia/wojciech-kasa.jpg`
## Michał Franc
**Ścieżka IT, dzień 1:** Rola developera w czasach AI
Michał Franc to principal engineer z 18-letnim doświadczeniem, który przeszedł całą drogę od juniora aż po principala w firmach produktowych, takich jak JustEat, JustGiving, Form3 i Affirm. Widzi swoją rolę jako architekta na dwóch poziomach: systemów oraz organizacji i sposobu, w jaki pracują ludzie. Budował skalowalne, niezawodne systemy rozproszone o globalnej skali, obsługujące dziesiątki milionów użytkowników i przetwarzające miliardy dolarów (Cloud Native, AWS, Platform Engineering, SRE, DevOps). Przede wszystkim jest jednak zorientowany na generowanie wartości biznesowej.

Po godzinach hobbystycznie pisze gry (mfranc.com/game), dużo w nie gra i jest fanatykiem vima, Dwarf Fortress oraz CDDA.
Zdjęcie: `zdjecia/michal-franc.jpg`
## Jakub Sikora
**Ścieżka IT, dzień 2:** Przejęliśmy drony i wywaliliśmy je z mapy. To samo mogę zrobić z Twoją zabezpieczoną usługą
Jakub buduje systemy zaufania dla pieniędzy i rozbiera je dla sportu. Na co dzień jest VP Engineering w fintechu na etapie Series B, czyli w Circit Ltd., które dostarcza globalnym firmom audytorskim i bankom infrastrukturę zgodną z SOC 2 i certyfikowaną przez SWIFT, a kiedy trzeba, także nocą, wciela się w CyberLegionistę.

Na Programistoku pokaże, co się dzieje, gdy bezpieczna komunikacja między usługami okazuje się ani autentyczna, ani prawdziwa, i dlaczego następne w kolejce jest Twoje API. Mówi z niewygodnej przestrzeni między formalną zgodnością z wymogami bezpieczeństwa a realnie sprawdzoną odpornością systemu.
Zdjęcie: `zdjecia/jakub-sikora.jpg`
## Łukasz Kałużny
**Ścieżka Biznes, dzień 1:** AI bez szamanów — reality check
Technology Advisor i Managing Partner w Protopia. Zajmuje się technologią wtedy, kiedy jest jeszcze „za wcześnie”, a nie wtedy, kiedy już każdy ma na to slajd: Azure od 2013, kontenery od 2014 (Docker/Kubernetes), a LLM-y dłubał jeszcze przed erą ChatGPT. Lubi sprawdzać trendy w praktyce: co realnie dowozi wartość, co generuje dług, a co jest tylko ładną ściemą.

W projektach kręci się wokół architektury, platform chmurowych, danych i automatyzacji, a także tego, jak to wszystko poskładać, żeby działało w rzeczywistości, a nie tylko na diagramie. Ma słabość do rozbrajania hype'u i opowieści z LinkedIna: od „AI-szamanii” po modne hasła, które dobrze wyglądają w poście, a gorzej w produkcji. Zwykle interesuje go moment, w którym kończy się magia, a zaczyna koszt, ryzyko i odpowiedzialność. Microsoft MVP nieprzerwanie od 2012. Współtwórca podcastu Patoarchitekci.
Zdjęcie: `zdjecia/lukasz-kaluzny.jpg`
## Oleksandr Lysenko
**Ścieżka IT, dzień 2:** The Human vs. the LLM: Measuring AI Efficiency
Oleksandr pracuje w R&D, zajmuje się AI i rozwiązywaniem złożonych problemów wokół danych finansowych i audytowych. Ma ponad 10 lat doświadczenia w inżynierii oprogramowania, zdobytego w fintechu, obszarze finansów i ryzyka oraz przy systemach danych dużej skali.

Przez lata budował platformy integracji bankowej łączące tysiące instytucji finansowych, pracował przy potokach danych o dużej skali i rozwijał rozwiązania oparte na ML oraz LLM. Dziś skupia się głównie na tym, jak zastosować AI do realnych problemów inżynierskich i biznesowych oraz jak zamieniać obiecujące pomysły w systemy produkcyjne.
Zdjęcie: `zdjecia/oleksandr-lysenko.jpg`
## Radek Maziarka
**Ścieżka IT, dzień 1:** Context Engineering: architektura wiedzy dla efektywnego dostarczania
Engineering Consultant z ponad 10-letnim doświadczeniem w branży. Pracuje przy pełnym zakresie tworzenia produktów cyfrowych, od budowy zespołów i organizacji, przez definiowanie celów i analizę wymagań, po tworzenie produktu cyfrowego i jego utrzymanie na produkcji. Zwolennik pracy zwinnej i automatyzacji procesów.
Zdjęcie: `zdjecia/radek-maziarka.jpg`
## Kamil Kiełbasa
**Ścieżka IT, dzień 2:** Czy potrzebujemy jeszcze architektów?
Kamil od piętnastu lat ogląda systemy od środka, zwykle w momencie, w którym coś już poszło nie tak. Twierdzi, że większość długu architektonicznego to nie zły kod, tylko granice postawione w miejscu, które wtedy wydawało się oczywiste.

Architekt i konsultant, Technical Lead w Jit Team. Budował hurtownie danych, rozbierał monolity, skalował zespoły od zera do kilkunastu osób i wprowadzał Event Storming tam, gdzie wcześniej istniały wyłącznie specyfikacje. DDD, systemy rozproszone, .NET, AWS, Kubernetes, ale najchętniej rozmawia o tym, dlaczego zespoły podejmują decyzje, które później same przeklinają.

Prowadzi bd90.pl i newsletter „The Architect's Edge”, współorganizuje Warsaw Software Architecture Group. Kolekcjonuje certyfikaty chmurowe, choć sam przyznaje, że żaden nie uchronił go przed nieudanym wdrożeniem. Gra na gitarze, ma słabość do doom metalu.
Zdjęcie: `zdjecia/kamil-kielbasa.jpg`
## Hubert Łępicki
**Ścieżka IT, dzień 2:** Inżynieria oprogramowania w dobie agentów AI
Hubert jest programistą z blisko dwudziestoletnim doświadczeniem. W swojej pracy zaczynał od PHP i Ruby on Rails, tworzył systemy w języku Elixir, a od początku roku 2026 programuje wyłącznie przy użyciu agentów AI.
Zdjęcie: `zdjecia/hubert-lepicki.jpg`
## Grzegorz Wilczura
**Ścieżka IT, dzień 2:** Czy potrzebujemy jeszcze architektów?
Inżynier oprogramowania z zamiłowania. Pracował jako programista, architekt, lider zespołu, kierownik działu technologicznego, a teraz ponownie jako programista.

Przez większość kariery zawodowej związany z obszarem finansowo-bankowym, ale miał też okazję pracować w sektorze transportu, turystyki, telekomunikacji i e-commerce.

Obecnie skoncentrowany na projektowaniu wydajnego i trwałego oprogramowania niezależnie od architektury czy infrastruktury.
Zdjęcie: `zdjecia/grzegorz-wilczura.jpg`
## Marcin Iwanowski
**Ścieżka IT, dzień 1:** Kiedy AI to za mało: Quantum
Microsoft MVP w kategorii Azure Application PaaS, współwłaściciel 4BEARS Sp. z o.o. dostarczającej ekspertów w swojej dziedzinie zachodnim rynkom IT, konsultant w SoftwareONE AG. Wcześniej programista, team leader, project manager, kierownik działów w organizacjach różnej wielkości, od kilkunastu do ponad stu tysięcy pracowników.

Aktywny trener współpracujący z największymi ośrodkami edukacyjnymi w Polsce. Wykładowca Warszawskiej Wyższej Szkoły Informatyki. Lider społeczności bstok.ms i lublin.ms, prelegent wielu wydarzeń ogólnopolskich. Od 2010 roku magister inżynier informatyki, absolwent Politechniki Białostockiej.
Zdjęcie: `zdjecia/marcin-iwanowski.jpg`
## Michał Matejczyk
**Ścieżka Biznes, dzień 1:** Dobre i złe wdrożenia od strony procesowej. Co firmy zrobiły, żeby dostać na czas to, czego realnie potrzebują.
Wiceprezes Zarządu i Dyrektor ds. Rozwoju w Entra Group. Ekspert z ponad 20-letnim doświadczeniem w obszarze produkcji, utrzymania ruchu, wdrażania projektów WCM w operacjach i zarządzania zmianą. Specjalizuje się w zmianach systemowych i procesowych w działach operacyjnych firm (produkcja, utrzymanie ruchu, jakość), angażowaniu i motywowaniu pracowników oraz zarządzaniu zmianą w oparciu o koncepcje Produkcji Klasy Światowej (WCM), TPM oraz Lean. Wypracowuje rozwiązania z zakresu zarządzania organizacją z wykorzystaniem wskaźników efektywności i wspiera firmy w transformacji oraz rozwoju kompetencji cyfrowych.

Doświadczenie zdobywał w Polsce i za granicą, pracując dla kluczowych branż, m.in. przemysłu spożywczego, farmaceutycznego, ciężkiego, maszynowego, meblowego, chemicznego i wydobywczego. W Entra Group odpowiada przede wszystkim za realizację projektów w obszarach Produkcji i Utrzymania Ruchu oraz doskonalenie umiejętności miękkich pracowników w działach operacyjnych.

Master Trener WCM, członek SIM (Stowarzyszenie Interim Managerów), autor publikacji naukowych z zakresu transformacji organizacji i korzyści z wdrażania modelu WCM. Absolwent kierunku Automatyka i Robotyka na Wydziale Elektrotechniki i Automatyki Politechniki Gdańskiej.
Zdjęcie: `zdjecia/michal-matejczyk.jpg`
## Piotr Werner
**Ścieżka Biznes, dzień 1:** Wdrożenie AI od Kuchni (Vikinga). Czy na pewno takie smaczne?
Mąż, ojciec, Head of Digital Analytics and Performance Marketing w Kuchni Vikinga. W codziennej pracy stara się tłumaczyć język techniczny na biznesowy (w obie strony) oraz odpowiadać na pytania: co, jak i dlaczego? Czasem również: kiedy?

W e-commerce od 2014 r. Pracował głównie w in-house'owych zespołach, ma za sobą także epizod agencyjny. Zbudował od podstaw zespół analityki internetowej w Orange Polska, który pozostawił w dobrych rękach i przeniósł się do podlaskiej Kuchni Vikinga.

Specjalizuje się w analityce, ale jako że ta trudno sobie radzi bez uporządkowanych procesów, dobrych definicji celów biznesowych i KPI, a także rozsądnie zarządzanych zespołów, to również w tych obszarach ma pewne doświadczenie.
Zdjęcie: `zdjecia/piotr-werner.jpg`
## Norbert Pawluczuk
**Ścieżka Biznes, dzień 1:** Transformacja cyfrowa w branży produkcyjnej bez budżetu z kosmosu. Lekcje z wdrożenia Showroomu 3D i aplikacji myINTERTECH.
Dyrektor Marketingu / CMO w Intertech Sp. z o.o., z wieloletnim doświadczeniem w budowaniu strategii marketingowej, rebrandingu oraz cyfryzacji procesów w branży maszynowej i produkcyjnej (wcześniej związany m.in. z SaMASZ Sp. z o.o. i Pronar Sp. z o.o.). W swojej pracy łączy klasyczny marketing B2B z nowoczesnymi narzędziami cyfrowego wsparcia sprzedaży (sales enablement), stawiając na rozwiązania, które przynoszą mierzalny zwrot i realną wartość biznesową bez zbędnego przepalania budżetu.

W Intertech odpowiada za całościową transformację wizerunkową marki oraz strategiczne projektowanie i wdrożenie cyfrowego ekosystemu klienta. Jest pomysłodawcą i inicjatorem projektu wirtualnego showroomu (3D/VR) oraz autorskiej aplikacji mobilnej myINTERTECH. Zwolennik praktycznego podejścia do technologii: traktuje ją nie jako marketingowy gadżet, lecz jako wieloetapowy proces skracający dystans do klienta. W ramach tworzonego środowiska digitalowego rozwija m.in. moduł „Mój Garaż” (dający użytkownikom maszyn natychmiastowy dostęp do dokumentacji i instrukcji), cyfrowy kanał zamówień części zamiennych, zdalne moduły szkoleniowe oraz narzędzia do budowania długofalowej bazy i relacji z użytkownikami końcowymi.
Zdjęcie: `zdjecia/norbert-pawluczuk.jpg`
## Przemysław Józwiakowski
**Ścieżka Biznes, dzień 2:** Gdzie naprawdę pękają wdrożenia AI w dużych organizacjach: ludzie, systemy, mindset
Zaczynał poza technologią, w budownictwie. Przejście do IT nauczyło go rzeczy, która została z nim na lata: najciekawsze rozwiązania powstają na styku dziedzin, a nie w ich środku. Przez 15 lat budował, skalował i uczył technologii — prowadził Akademię Programowania, przez którą przeszło 500 programistów, zarządzał 50-osobowym zespołem technicznym, stworzył metodologię „Metawarstwy” używaną dziś przez ponad 10 000 osób.

Dziś prowadzi Localhost Group — firmę, która robi coś celowo niepopularnego w branży. Zamiast sprzedawać firmom automatyzacje, buduje w nich wewnętrzne działy AI, które po dwunastu miesiącach działają samodzielnie. „Nie sprzedajemy narzędzi. Budujemy kompetencję, żeby je mieć na własność” — to zdanie kosztuje Localhost Group przychód z wiecznych retainerów i jest świadomym wyborem.

Pracował m.in. z Wealthon, Velo Leasing, Esotiq & Henderson, Group One Media, Exact Forestall, Automation Trader, Dr Optima i by.vet — fintech, leasing, retail, media, SaaS, przemysł, farmacja, weterynaria. Efekty liczone są w setkach tysięcy dolarów rocznych oszczędności, w procesach skróconych z godzin do minut i w kosztach obsługi spadających o rzędy wielkości. 97% automatyzacji wdrożonych w 2025 roku nadal działa w produkcji — przy rynkowej średniej, w której mniej niż 10% use case'ów AI w ogóle do produkcji dociera.

Uczy tego, co robi. Jest autorem kursów, w których osoby bez wykształcenia technicznego budują własne narzędzia AI — m.in. sześciotygodniowego programu „VibeCoding dla każdego”, zrealizowanego z CampusAI, gdzie wcześniej odpowiadał za technologię jako współzałożyciel i CTO platformy z 35 tysiącami użytkowników. Doradza funduszom venture capital i kadrze zarządzającej.
Zdjęcie: `zdjecia/przemyslaw-jozwiakowski.jpg`
## Maciej Lotkowski
**Ścieżka Biznes, dzień 2:** 95% wdrożeń to zmarnowane pieniądze. Konsultanci i tak wystawią fakturę.
Zdjęcie: `zdjecia/maciej-lotkowski.jpg`
## Gabriela Załoga
**Ścieżka Biznes, dzień 2:** Czy ludzie naprawdę nie lubią zmian? O cyfryzacji z ludzką twarzą
Zdjęcie: `zdjecia/gabriela-zaloga.jpg`
## Katarzyna Onoszko
**Ścieżka Biznes, dzień 2:** Zakup i wdrożenie oprogramowania okiem klienta — case study Panorama Druk
Zdjęcie: `zdjecia/katarzyna-onoszko.jpg`
## Bożena Datczuk
**Ścieżka Biznes, dzień 2:** Cyfryzacja w produkcji mebli — case study TOBO
Prezes firmy TOBO Sp. z o.o. z siedzibą w Kurianach koło Białegostoku. Absolwentka Wydziału Ekonomii Uniwersytetu w Białymstoku z ponad 30-letnim doświadczeniem biznesowym. Od 1998 roku wraz z mężem Tomaszem prowadzi TOBO — producenta mebli biurowych, gabinetowych, recepcyjnych, hotelowych i edukacyjnych, w tym nagradzanej linii 4SENIOR dla stref senioralnych. Firma stawia na ergonomię, akustykę i prozdrowotne rozwiązania przestrzeni pracy, a jej produkty wyróżniano m.in. Złotym Medalem Grupy MTP, Diamentem Meblarstwa, Dobrym Wzorem, Must Have i Podlaską Marką.

Wiceprezes Zarządu Fundacji Technotalenty, organizacji promującej kulturę innowacji poprzez wsparcie firm w pozyskiwaniu talentów i budowanie relacji biznes–nauka. Członkini Rady Izby Przemysłowo-Handlowej w Białymstoku (od 2019, druga kadencja jako sekretarz), Podlaskiej Rady Przedsiębiorczości przy Marszałku Województwa Podlaskiego, Grupy Roboczej ds. specjalizacji regionalnej gospodarki przy Departamencie Innowacji i Przedsiębiorczości Urzędu Marszałkowskiego oraz Rady Rozwoju Obszaru Gospodarczego Suwalskiej Specjalnej Strefy Ekonomicznej. Zasiada też w Radzie Rozwoju Wydziału Architektury i Radzie Przedsiębiorców Wydziału Inżynierii Zarządzania Politechniki Białostockiej. Współorganizatorka cyklicznych bali charytatywnych.
Zdjęcie: `zdjecia/bozena-datczuk.jpg`
## Piotr Krych
**Ścieżka Biznes, dzień 2:** Możliwości narzędzi AI w codziennej pracy
W branży IT od 18 lat i przez cały ten czas czynny developer, choć po drodze przeszedł większość ról w wytwarzaniu oprogramowania. Właściciel Monolynx.

Dziś specjalizuje się w praktycznym zastosowaniu sztucznej inteligencji w firmach: Claude AI (Chat, Cowork, Code), technologiczne wsparcie pracy i transformacja cyfrowa organizacji. Prowadzi szkolenia z narzędzi AI dla MŚP i wdraża asystentów AI u klientów. Wystąpił m.in. na BRAVE AI Meetup w Białymstoku. Nie mówi o AI z perspektywy prezentacji — pokazuje to, czego sam używa w codziennej pracy.
Zdjęcie: `zdjecia/piotr-krych.jpg`
## Piotr Jurewicz
**Ścieżka Biznes, dzień 2:** Wiedza organizacji w grafie, nie w głowach
Piotr zakochał się w języku Ruby 12 lat temu i ten związek trwa do dziś. Kiedyś jako one-man army wdrażał platformę e-commerce. Dziś, jako konsultant w Arkency, wchodzi w duże systemy legacy i pomaga biznesom operować tam, gdzie niejeden już by załamał ręce. Dzięki temu poznał od podszewki branżę ubezpieczeniową i fintech.

Jego nieoficjalna misja w Arkency: utrwalać wiedzę organizacji poza ulotną pamięcią jej pracowników. Tak zaczęła się jego przygoda ze sztuczną inteligencją.
Zdjęcie: `zdjecia/piotr-jurewicz.jpg`
## Piotr Janiak
**Ścieżka Biznes, dzień 1:** Zanim zbudujesz agenta AI, uporządkuj wiedzę. Lekcje z chaosu w organizacji
Zdjęcie: `zdjecia/piotr-janiak.jpg`
## Adam Piotrowski
**Ścieżka Biznes, dzień 1:** Biznes nam nie ufa — i wcale im się nie dziwię
Zdjęcie: `zdjecia/adam-piotrowski.jpg`
## Michał Szumski
**Ścieżka Biznes, dzień 2:** O transformacji, jaką przeszedł nasz dział rozwoju przez ostatnie 10 lat
Pięć lat w Anglii: liceum i inżynier z matematyki na Loughborough University, potem trzy lata magisterki z automatyki i robotyki na Politechnice Warszawskiej. W Plum pracuje od 15 lat — zaczynał jako handlowiec, pracował w marketingu, na produkcji, jako programista, Scrum Master, Product Owner i kierownik sekcji programistów, a od ponad dwóch lat jest Prezesem Zarządu. Prywatnie siłownia, bieganie, książki i gry planszowe z dziećmi.

Plum specjalizuje się we wdrażaniu i produkcji elektroniki NB-IoT w branżach HVAC, gaz i woda. R&D, jakość i rozwój produktu firma ma wpisane w DNA.
Zdjęcie: `zdjecia/michal-szumski.jpg`
## Bartosz Awruk
**Ścieżka Biznes, dzień 1:** Case study LumoSteel
Zdjęcie: `zdjecia/bartosz-awruk.jpg`
## Grzegorz Sienkiewicz
**Ścieżka Biznes, dzień 1:** Rzemiosło kontra AI. Case study 4szpaki
Zdjęcie: `zdjecia/grzegorz-sienkiewicz.jpg`
## Konrad Zawistowski
**Ścieżka Biznes, dzień 2:** Migracja z ERP-a do ERP-a — case study Ikonka.eu
_Brak zdjęcia w paczce._
## Krzysztof Kozłowski
**Ścieżka Biznes, dzień 2:** Aplikacja self-made do prowadzenia produkcji — case study Inwestprodukt
_Brak zdjęcia w paczce._
## Marek Ziemba
**Ścieżka Biznes, dzień 2:** Jak zepsuć marketing i sprzedaż B2B technologią
_Brak zdjęcia w paczce._
